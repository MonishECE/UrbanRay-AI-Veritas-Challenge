"""AI shortwave surrogate with a physically constrained, auditable inference API.

The model learns *simulator-generated* multibounce shortwave absorption (W/m2),
not measured temperatures. A reference radiative transfer solver remains the
scientific baseline. Never treat the surrogate's aggregate source cap as proof
of per-face conservation or ground-truth accuracy.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
from typing import Any

from geometry_features import GEOMETRY_FEATURES, GeometryGraph, build_geometry_graph

import joblib
import sklearn
import numpy as np
import pandas as pd

# Duplicated explicitly from train_surrogate.PHYSICS to allow use from src/.
# The loader checks the persisted schema before any predictions.
MODEL_FEATURES = (
    'area_m2', 'z_m', 'albedo_assumed', 'kind_code', 'source_flux_Wm2',
    'direct_plus_sky_abs_Wm2', 'DNI_grid_Wm2', 'DHI_grid_Wm2',
    'air_temp_C_grid', 'wind_grid_ms', 'sun_east', 'sun_north',
    'sun_up', 'sky_fraction_modeled', 'nx', 'ny', 'nz',
)
KIND_CODES = {'roof': 0, 'wall': 1, 'ground': 2}
ENHANCED_MODEL_FEATURES = MODEL_FEATURES + GEOMETRY_FEATURES
TRAINED_ROOF_ALBEDOS = (0.18, 0.58)


@dataclass(frozen=True)
class ShortwaveEstimate:
    flux_Wm2: np.ndarray
    metadata: dict[str, Any]


def load_surrogate(path: str | Path) -> dict[str, Any]:
    """Load a *trusted project-generated* joblib bundle, with schema checks.

    Warning: joblib uses pickle and loading unknown files can execute code.
    Train your own model using train_surrogate.py if artifact provenance is not
    trusted. Pin the scikit-learn version to the one used for training.
    """
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f'Surrogate not found: {p}')
    obj = joblib.load(p)
    if not isinstance(obj, dict) or not callable(getattr(obj.get('model'), 'predict', None)):
        raise ValueError('Expected a train_surrogate.py model bundle.')
    features = obj.get('features')
    if list(features or []) not in (list(MODEL_FEATURES),list(ENHANCED_MODEL_FEATURES)):
        raise ValueError(f'Feature schema mismatch in {p}. Model must be retrained.')
    if obj.get('target') != 'multibounce_abs_Wm2':
        raise ValueError('This model does not predict the expected simulated radiation target.')
    if obj.get('prediction_mode','direct') not in ('direct','residual'):
        raise ValueError('Unknown surrogate output mode.')
    if obj.get('target_transform', 'none') not in ('none','log1p'):
        raise ValueError('Unknown target transform.')
    if obj.get('sklearn_version') and obj['sklearn_version'] != sklearn.__version__:
        raise RuntimeError(f"Model saved with scikit-learn {obj['sklearn_version']} but this environment has {sklearn.__version__}. Retrain or match version.")
    return obj


def feature_frame(scene: dict, source_W: np.ndarray, sky: np.ndarray,
                  sun: np.ndarray, weather_row: Any,
                  albedo_by_face: np.ndarray,
                  geometry_graph: GeometryGraph | None = None,
                  include_geometry: bool = False) -> pd.DataFrame:
    """Exactly reproduce the numerical features used to train the surrogate.

    scene/source/sky must come from the SAME scene and same weather hour.
    """
    area = np.asarray(scene['area'], dtype=float)
    source = np.asarray(source_W, dtype=float)
    sky = np.asarray(sky, dtype=float)
    alpha = np.asarray(albedo_by_face, dtype=float)
    sun = np.asarray(sun, dtype=float)
    n = len(area)
    if source.shape != area.shape or sky.shape != area.shape or alpha.shape != area.shape:
        raise ValueError('Face input array lengths do not match geometry.')
    if sun.shape != (3,):
        raise ValueError('Sun direction must have three components.')
    if (np.any(area <= 0) or np.any(source < -1.e-9) or
        np.any((sky < 0) | (sky > 1)) or np.any((alpha < 0) | (alpha > 1))):
        raise ValueError('Nonphysical area, source, sky visibility, or albedo.')
    kind = pd.Series(scene['kind']).map(KIND_CODES)
    if kind.isna().any():
        raise ValueError('Unknown surface kind')
    flux = np.maximum(0., source) / area
    values = {
        'area_m2': area,
        'z_m': np.asarray(scene['center'])[:, 2],
        'albedo_assumed': alpha,
        'kind_code': kind.to_numpy(dtype=np.int64),
        'source_flux_Wm2': flux,
        'direct_plus_sky_abs_Wm2': flux * (1 - alpha),
        'DNI_grid_Wm2': np.full(n, float(weather_row['direct_normal_irradiance_instant'])),
        'DHI_grid_Wm2': np.full(n, float(weather_row['diffuse_radiation_instant'])),
        'air_temp_C_grid': np.full(n, float(weather_row['temperature_2m'])),
        'wind_grid_ms': np.full(n, float(weather_row['wind_speed_10m'])),
        'sun_east': np.full(n, float(sun[0])),
        'sun_north': np.full(n, float(sun[1])),
        'sun_up': np.full(n, float(sun[2])),
        'sky_fraction_modeled': sky,
        'nx': np.asarray(scene['normal'])[:, 0],
        'ny': np.asarray(scene['normal'])[:, 1],
        'nz': np.asarray(scene['normal'])[:, 2],
    }
    frame = pd.DataFrame(values, columns=list(MODEL_FEATURES))
    if include_geometry:
        graph = geometry_graph if geometry_graph is not None else build_geometry_graph(scene)
        proxy = graph.features(flux, alpha)
        for index, feature in enumerate(GEOMETRY_FEATURES):
            frame[feature] = proxy[:,index]
    if not np.isfinite(frame.to_numpy(dtype=float)).all():
        raise ValueError('Nonfinite AI features')
    return frame


def predict_from_frame(bundle: dict, frame: pd.DataFrame,
                       source_W: np.ndarray, area_m2: np.ndarray,
                       enforce_source_cap: bool = True) -> ShortwaveEstimate:
    """Predict nonnegative absorption, force exactly zero for zero-sun cases.

    An aggregate cap (optional) prevents total absorbed model power exceeding
    source input. It is a pragmatic guard, not a replacement for a physical
    energy-conservation or longwave validation test.
    """
    required = list(bundle.get('features',MODEL_FEATURES))
    if required not in (list(MODEL_FEATURES),list(ENHANCED_MODEL_FEATURES)) or list(frame.columns) != required:
        raise ValueError('Inference feature columns differ from trained schema.')
    src = np.asarray(source_W, dtype=float)
    area = np.asarray(area_m2, dtype=float)
    if len(frame) != len(src) or len(src) != len(area):
        raise ValueError('Model data length mismatch.')
    if np.any(src < -1e-9) or np.any(area <= 0) or not np.isfinite(src).all():
        raise ValueError('Invalid source or area.')
    start = perf_counter()
    if float(src.sum()) <= 1e-9:
        pred = np.zeros_like(area)
        zero_night = True
    else:
        learned = np.asarray(bundle['model'].predict(frame), dtype=float).reshape(-1)
        if bundle.get('target_transform','none') == 'log1p':
            learned = np.expm1(np.clip(learned,-30.,30.))
        if bundle.get('prediction_mode','direct') == 'residual':
            # AI learns extra absorption attributable to multibounce reflections.
            # The nonnegative correction preserves the direct/sky physical floor.
            pred = frame['direct_plus_sky_abs_Wm2'].to_numpy() + np.maximum(0.,learned)
        else:
            pred = np.maximum(0., learned)
        zero_night = False
    raw_total = float(np.dot(pred, area))
    source_total = float(src.sum())
    if not np.isfinite(pred).all():
        raise ValueError('Nonfinite surrogate prediction.')
    scale = min(1., source_total / raw_total) if enforce_source_cap and raw_total > 0 else 1.
    result = pred * scale
    ms = (perf_counter() - start) * 1000
    meta = {
        'model': 'physics-informed_gradient_boosting_surrogate',
        'prediction_mode': bundle.get('prediction_mode','direct'),
        'geometry_features_used': list(frame.columns) == list(ENHANCED_MODEL_FEATURES),
        'label_type': 'simulator-generated_shortwave_Wm2',
        'inference_ms_excludes_feature_construction': float(ms),
        'initial_W': source_total,
        'absorbed_W': float(np.dot(result, area)),
        'raw_predicted_absorbed_W': raw_total,
        'pre_cap_source_excess_W': max(0., raw_total-source_total),
        'energy_cap_scale': float(scale),
        'source_cap_applied': bool(scale < 1),
        'all_zero_source': bool(zero_night),
        'energy_balance_verified': False,
        'surface_temp_accuracy_established': False,
    }
    return ShortwaveEstimate(result, meta)


def infer_shortwave(bundle: dict, scene: dict, source_W: np.ndarray, sky: np.ndarray,
                    sun: np.ndarray, weather_row: Any,
                    alpha_by_face: np.ndarray,
                    geometry_graph: GeometryGraph | None = None) -> ShortwaveEstimate:
    start = perf_counter()
    augmented = list(bundle.get('features', MODEL_FEATURES)) == list(ENHANCED_MODEL_FEATURES)
    frame = feature_frame(scene, source_W, sky, sun, weather_row, alpha_by_face,
        geometry_graph=geometry_graph, include_geometry=augmented)
    prediction = predict_from_frame(bundle, frame, source_W, scene['area'])
    prediction.metadata['feature_construction_plus_prediction_ms'] = (perf_counter()-start)*1000
    return prediction

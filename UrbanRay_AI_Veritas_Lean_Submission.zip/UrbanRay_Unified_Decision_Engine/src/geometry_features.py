"""Fast, reproducible neighboring-surface *proxy* features for UrbanRay.

Features use only geometry, albedo, direct+sky source, and known sun/weather.
No target values, true view-factor operator, simulated multi-bounce result,
measured temperatures, or held-out labels enter this module.

The sparse cosine-distance graph omits occlusion: it is NOT a physics solver,
visibility test, or proof that a neighboring face actually illuminates another.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.spatial import cKDTree

GEOMETRY_FEATURES = (
    'neighbor_buildings_100m',
    'nearest_other_building_m',
    'neighbor_roof_height_above_m',
    'facing_exchange_proxy',
    'neighbor_reflection_proxy_Wm2',
)


@dataclass
class GeometryGraph:
    kernel: csr_matrix
    static: np.ndarray
    face_count: int
    params: dict

    def features(self, source_flux_Wm2, albedo) -> np.ndarray:
        src = np.asarray(source_flux_Wm2, dtype=float)
        alpha = np.asarray(albedo, dtype=float)
        if src.shape != (self.face_count,) or alpha.shape != src.shape:
            raise ValueError('Geometry proxy input sizes must match face count')
        if not np.isfinite(src).all() or not np.isfinite(alpha).all() or (src < -1e-9).any() or ((alpha<0)|(alpha>1)).any():
            raise ValueError('Nonphysical geometry proxy inputs')
        reflected_in = np.asarray(self.kernel @ (np.maximum(0., src) * alpha)).ravel()
        return np.column_stack([self.static, reflected_in])


def build_geometry_graph(scene: dict, *, max_neighbors: int = 48,
                         radius_m: float = 110., minimum_distance_m: float = 4.) -> GeometryGraph:
    """Create one sparse, reusable geometric proxy graph per fixed scene.

    At most max_neighbors nearby other patches per target, ~O(n log n + nk).
    The max_neighbor limit is a deliberate approximation; no ray tracing.
    """
    center = np.asarray(scene['center'],dtype=float)
    normal = np.asarray(scene['normal'],dtype=float)
    area = np.asarray(scene['area'],dtype=float)
    kind = np.asarray(scene['kind']).astype(str)
    ids = np.asarray(scene['building_id']).astype(str)
    n = len(area)
    if not (center.shape == (n,3) and normal.shape==(n,3) and kind.shape==(n,) and ids.shape==(n,)):
        raise ValueError('Incomplete geometry for neighboring-face feature construction')
    if not np.isfinite(center).all() or not np.isfinite(normal).all() or not np.isfinite(area).all() or (area<=0).any():
        raise ValueError('Nonfinite geometry or nonpositive face area')
    if max_neighbors < 1 or radius_m<=0 or minimum_distance_m<=0:
        raise ValueError('Invalid geometry graph configuration')
    # Build on the whole known mesh; never infer neighbors using test labels.
    distances, nbr = cKDTree(center).query(center,k=min(n,max_neighbors+1),distance_upper_bound=radius_m)
    if np.ndim(nbr)==1:
        nbr=nbr[:,None];distances=distances[:,None]
    static = np.zeros((n,4),dtype=float)
    static[:,1] = radius_m  # explicit missing-neighbor sentinel
    rr=[];cc=[];ww=[]
    for i in range(n):
        candidates=nbr[i]
        distances_i=distances[i]
        eligible=(candidates<n)&(candidates!=i)&np.isfinite(distances_i)
        j=candidates[eligible]
        dd=distances_i[eligible]
        # Exclude intra-building interactions. Ground is separate context.
        other=(ids[j]!=ids[i])
        j=j[other];dd=dd[other]
        if len(j)==0:continue
        buildings={bid for bid in ids[j] if bid!='GROUND'}
        static[i,0]=len(buildings)
        static[i,1]=float(np.min(dd))
        roofs=j[(kind[j]=='roof')&(ids[j]!='GROUND')]
        if len(roofs):static[i,2]=max(0.,float(np.max(center[roofs,2])-center[i,2]))
        disp = center[j]-center[i]
        d2 = np.sum(disp**2,axis=1)
        direction = disp / np.maximum(np.sqrt(d2)[:,None],1e-9)
        facing_i=np.maximum(0.,direction@normal[i])
        facing_j=np.maximum(0.,np.einsum('ij,ij->i',normal[j],-direction))
        # Capped geometric proxy, not a physically closed view-factor matrix.
        weight=np.minimum(.7, area[j] / (np.pi*np.maximum(d2,minimum_distance_m**2)) * facing_i*facing_j)
        good=weight>0
        rr.extend([i]*int(good.sum()));cc.extend(j[good].tolist());ww.extend(weight[good].tolist())
        static[i,3]=float(weight.sum())
    kernel=csr_matrix((ww,(rr,cc)),shape=(n,n),dtype=float)
    return GeometryGraph(kernel,static,n,{'radius_m':radius_m,'max_neighbors':max_neighbors,
        'minimum_distance_m':minimum_distance_m,'not_line_of_sight_verified':True,
        'nonzero_facing_links':int(kernel.nnz)})


def table_scene(geometry_faces: pd.DataFrame) -> dict:
    g=geometry_faces.sort_values('face_id')
    face_ids=g['face_id'].to_numpy(dtype=int)
    if not np.array_equal(face_ids,np.arange(len(g))):
        raise ValueError('Geometry requires ordered complete mesh face IDs 0..N-1')
    required={'x_m','y_m','z_m','nx','ny','nz','area_m2','kind','building_id'}
    if not required.issubset(g.columns):raise ValueError('Missing geometry columns: '+str(required-set(g.columns)))
    return {'center':g[['x_m','y_m','z_m']].to_numpy(dtype=float),
            'normal':g[['nx','ny','nz']].to_numpy(dtype=float),
            'area':g['area_m2'].to_numpy(dtype=float),
            'kind':g['kind'].astype(str).to_numpy(),
            'building_id':g['building_id'].astype(str).to_numpy()}


def augment_full_scene_table(df:pd.DataFrame, *, graph:GeometryGraph|None=None) -> tuple[pd.DataFrame,GeometryGraph]:
    """Add proxy columns for fully populated time/scenario mesh scenes.

    Must call BEFORE splitting dates/blocks so neighbor source exposure is
    computed exactly as it would be at deployment with full visible geometry.
    This is allowed transductive geometry, never transductive target labels.
    """
    if df.empty:raise ValueError('Cannot augment empty scene')
    if 'face_id' not in df or 'source_flux_Wm2' not in df or 'albedo_assumed' not in df:
        raise ValueError('Missing required face/source inputs')
    if df.duplicated(['time_utc','scenario','face_id']).any():
        raise ValueError('Duplicate face IDs per scene/hour')
    first=df.drop_duplicates('face_id')
    # Static context MUST remain fixed for the whole archived dataset.
    # Failing closed here prevents silently training with incorrect neighbors.
    static_columns=['x_m','y_m','z_m','nx','ny','nz','area_m2']
    spread=df.groupby('face_id',sort=False)[static_columns].agg(['min','max'])
    for c in static_columns:
        if (spread[(c,'max')]-spread[(c,'min')]>1e-8).any():
            raise ValueError('Geometry changes across scene hours for '+c)
    if df.groupby('face_id',sort=False)[['kind','building_id']].nunique().to_numpy().max()>1:
        raise ValueError('Face type/building membership changes across scene hours')
    graph=graph if graph is not None else build_geometry_graph(table_scene(first))
    out=df.copy()
    values=np.empty((len(out),len(GEOMETRY_FEATURES)),dtype=float)
    for _,g in out.groupby(['time_utc','scenario'],sort=False):
        ordering=g['face_id'].to_numpy(dtype=int)
        if len(g)!=graph.face_count or not np.array_equal(np.sort(ordering),np.arange(graph.face_count)):
            raise ValueError('Incomplete scene group: geometry features require all faces')
        arr=graph.features(g.source_flux_Wm2.to_numpy()[np.argsort(ordering)],
                           g.albedo_assumed.to_numpy()[np.argsort(ordering)])
        values[out.index.get_indexer(g.index)] = arr[ordering]
    for idx,c in enumerate(GEOMETRY_FEATURES):out[c]=values[:,idx]
    if not np.isfinite(values).all():raise ValueError('Invalid geometric features')
    return out,graph

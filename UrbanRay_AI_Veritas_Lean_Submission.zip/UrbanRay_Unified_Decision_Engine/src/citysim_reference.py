"""UrbanRay CitySim: scalable 3-D shortwave + simplified urban thermal physics.

IMPORTANT SCOPE: Synthetic building array, assumed materials/weather, approximate
Lambertian Monte-Carlo view factors, semi-empirical heat transfer. NOT calibrated
or validated against real city temperature/wind measurements. SI units throughout.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
import math
import numpy as np
from scipy.sparse import coo_matrix, csr_matrix, diags
from numba import njit

STEFAN = 5.670374419e-8
LAT,LON=40.753,-73.986
DENSITY_AIR=1.18
CP_AIR=1005.

@dataclass(frozen=True)
class Material:
    albedo: float
    emissivity: float
    conductivity: float       # W/(m K)
    volumetric_heat: float    # J/(m3 K)
    rough_length: float       # m for convection

MATERIALS = {
    'roof': Material(.18,.91,0.85,1.55e6,5.),
    'wall': Material(.30,.92,1.25,1.80e6,5.),
    'ground': Material(.12,.95,.76,1.65e6,4.)
}

@dataclass(frozen=True)
class Scenario:
    name: str
    roof_albedo: float
    cloud_fraction: float
    wind_ref_ms: float

SCENARIOS=(
    Scenario('baseline',.18,.25,3.5),
    Scenario('cool_roofs',.58,.25,3.5),
    Scenario('overcast',.18,.80,3.5),
    Scenario('windy',.18,.25,7.0),
)


def solar_position(dt: datetime, latitude:float=LAT, longitude:float=LON):
    """Approximate NOAA astronomical sun vector, UTC offset from aware local time."""
    if dt.tzinfo is None: raise ValueError('timezone-aware datetime is required')
    local=dt.astimezone(ZoneInfo('America/New_York'))
    n=local.timetuple().tm_yday
    days=366 if local.year%4==0 and (local.year%100!=0 or local.year%400==0) else 365
    hours=local.hour+local.minute/60+local.second/3600
    gamma=2*np.pi/days*(n-1+(hours-12)/24)
    eq=229.18*(.000075+.001868*np.cos(gamma)-.032077*np.sin(gamma)-.014615*np.cos(2*gamma)-.040849*np.sin(2*gamma))
    dec=(.006918-.399912*np.cos(gamma)+.070257*np.sin(gamma)-.006758*np.cos(2*gamma)+.000907*np.sin(2*gamma)-.002697*np.cos(3*gamma)+.00148*np.sin(3*gamma))
    zoneh=local.utcoffset().total_seconds()/3600
    ha=np.deg2rad(((hours*60+eq+4*longitude-60*zoneh)%1440)/4-180)
    phi=np.deg2rad(latitude)
    d=np.array([-np.cos(dec)*np.sin(ha), np.cos(phi)*np.sin(dec)-np.sin(phi)*np.cos(dec)*np.cos(ha),
                np.sin(phi)*np.sin(dec)+np.cos(phi)*np.cos(dec)*np.cos(ha)])
    d=d/np.linalg.norm(d)
    return d, float(np.rad2deg(np.arcsin(d[2])))


def haurwitz_ghi(cosz):
    c=np.asarray(cosz,dtype=float)
    return np.where(c>0,1098*np.maximum(c,0)*np.exp(-0.059/np.maximum(c,1e-6)),0.).item() if c.ndim==0 else np.where(c>0,1098*c*np.exp(-0.059/np.maximum(c,1e-6)),0.)


def airmass_kasten_young(zenith_deg):
    """Kasten-Young 1989 air mass for z < 90 deg; infinity below horizon."""
    z=float(zenith_deg)
    return float('inf') if z>=90 else float(1/(np.cos(np.deg2rad(z))+.50572*(96.07995-z)**(-1.6364)))


def erbs_decompose(ghi, solar_zenith_deg, doy):
    """Erbs hourly diffuse fraction, analytic DNI/DHI/energy closure."""
    z=float(solar_zenith_deg); ghi=float(ghi)
    if z>=87 or ghi<=0: return 0.,max(ghi,0.),0.
    cosz=np.cos(np.deg2rad(z))
    g0=1367*(1+.033*np.cos(2*np.pi*(doy-3)/365.))
    kt=np.clip(ghi/(g0*cosz),0,1)
    if kt<=.22: kd=1-.09*kt
    elif kt<=.8:kd=.9511-.1604*kt+4.388*kt**2-16.638*kt**3+12.336*kt**4
    else:kd=.165
    dhi=np.clip(kd,0,1)*ghi
    dni=max(0.,(ghi-dhi)/cosz)
    return float(dni),float(dhi),float(kt)


def irradiance_weather(dt, cloud_fraction):
    """Assumed cloud cover, not historical observations; W/m²."""
    sun,elev=solar_position(dt)
    cosz=max(0.,sun[2]); cloud=float(np.clip(cloud_fraction,0,1))
    ghi_clear=haurwitz_ghi(cosz)
    ghi=ghi_clear*(1-.75*cloud**3.4)
    dni,dhi,kt=erbs_decompose(ghi,90-elev,dt.timetuple().tm_yday)
    return {'sun':sun,'elevation_deg':elev,'airmass':airmass_kasten_young(90-elev),
            'clear_ghi':ghi_clear,'ghi':ghi,'dni':dni,'dhi':dhi,'kt':kt,'cloud':cloud}


def wind_profile(z, u_ref, z_ref=100., z0=.9, displacement=8.):
    """Ideal logarithmic mean wind (no prediction of canyon turbulence)."""
    if z_ref<=displacement+z0 or z0<=0:raise ValueError('Invalid log-law parameters')
    z=np.asarray(z,dtype=float)
    v=np.maximum(z-displacement,1.001*z0)
    speed=np.asarray(u_ref)*np.log(v/z0)/np.log((z_ref-displacement)/z0)
    return np.maximum(0,speed)


def air_properties(T_k):
    t=np.asarray(T_k,dtype=float)
    mu=1.716e-5*(t/273.15)**1.5*(273.15+110.4)/(t+110.4)
    rho=101325./(287.058*t)
    k=.0241*(t/273.15)**.9
    pr=.71+np.zeros_like(t)
    return rho,mu,k,pr


def convection_coefficient(surface_T, air_T, wind_speed, length, vertical=True):
    """Forced flat-plate Nu plus Churchill-Chu free Nu with cubic combination.
    Approximation: exposure and canyon turbulence not explicitly resolved.
    """
    tf=np.clip((np.asarray(surface_T)+np.asarray(air_T))/2,240,360)
    rho,mu,k,pr=air_properties(tf)
    U=np.asarray(wind_speed)
    L=np.maximum(.1,np.asarray(length))
    re=np.maximum(0.,rho*U*L/mu)
    nu_lam=.664*np.sqrt(re)*pr**(1/3)
    nu_turb=np.maximum(0,(.037*np.maximum(re,1)**.8-871))*pr**(1/3)
    nu_forced=np.where(re<=5e5,nu_lam,nu_turb)
    beta=1/tf
    nu_kin=mu/rho;alpha=k/(rho*1005.)
    ra=9.81*beta*np.abs(np.asarray(surface_T)-np.asarray(air_T))*L**3/(nu_kin*alpha)
    nu_free=(.825+(.387*np.maximum(ra,0)**(1/6))/((1+(.492/pr)**(9/16))**(8/27)))**2
    # horizontal surface free-convection: simpler orientation-sensitive correlation
    if isinstance(vertical,np.ndarray):
        horizontal=np.where(np.asarray(surface_T)>=np.asarray(air_T),.54,.27)*np.maximum(ra,0)**.25
        nu_free=np.where(vertical,nu_free,horizontal)
    elif not vertical:
        nu_free=np.where(np.asarray(surface_T)>=np.asarray(air_T),.54,.27)*np.maximum(ra,0)**.25
    hf=nu_forced*k/L;hn=nu_free*k/L
    return (hf**3+hn**3)**(1/3)


def brunt_cloud_longwave(T_air_k, relative_humidity, cloud_fraction):
    """Empirical Brunt clear-sky emissivity + explicit approximate cloud enhancement."""
    tc=float(T_air_k)-273.15
    es_hpa=6.112*np.exp(17.67*tc/(tc+243.5))
    e_hpa=np.clip(float(relative_humidity),0,1)*es_hpa
    eps_clear=np.clip(.51+.066*np.sqrt(e_hpa),.45,.97)
    eps_sky=min(1.,eps_clear+(.98-eps_clear)*float(np.clip(cloud_fraction,0,1))**2)
    return float(eps_sky*STEFAN*T_air_k**4), float(eps_sky)


def drag_force(rho, speed, cd, frontal_area):
    return .5*float(rho)*np.asarray(speed)**2*float(cd)*np.asarray(frontal_area)


def material_capacity(material: Material):
    """Daily harmonic thermal penetration-depth lumped storage estimate."""
    omega=2*np.pi/86400
    delta=np.sqrt(2*material.conductivity/(material.volumetric_heat*omega))
    return material.volumetric_heat*delta, material.conductivity/delta, delta


@dataclass
class City:
    centers: np.ndarray
    normals: np.ndarray
    areas: np.ndarray
    kind: np.ndarray   # 0 roof, 1 wall, 2 ground
    bid: np.ndarray
    corners: np.ndarray  # each patch 4x3, for uniform sample
    boxes: np.ndarray    # xmin ymin 0 xmax ymax height
    ground_map: np.ndarray # per grid cell indices [east_strip,north_strip]
    pitch: float
    width: float
    nx: int
    ny: int
    kind_names: tuple = ('roof','wall','ground')


def build_synthetic_city(nx=20,ny=21,pitch=37.,width=25.,seed=2026,height_samples_m=None):
    """420 rectangular boxes, 4 walls+roof+2 street strips each.
    Clearly synthetic; heights are scenario inputs, not measured NYC data.
    """
    rng=np.random.default_rng(seed)
    boxes=[];corners=[];norm=[];areas=[];kind=[];bid=[]
    ground_map=np.empty((nx,ny,2),dtype=np.int32)
    def patch(p,q,r,s,n,k,b):
        quad=np.array([p,q,r,s],dtype=float)
        corners.append(quad);norm.append(n)
        areas.append(np.linalg.norm(np.cross(quad[1]-quad[0],quad[3]-quad[0])))
        kind.append(k);bid.append(b)
        return len(areas)-1
    for ix in range(nx):
      for iy in range(ny):
        i=ix*ny+iy;x=ix*pitch;y=iy*pitch
        # Reproducible four-height urban morphology with small variation.
        if height_samples_m is None:
            h=float(rng.choice([14.,26.,42.,68.])+rng.uniform(-2.5,2.5))
        else:
            sample=np.asarray(height_samples_m,dtype=float)
            if len(sample)==0 or not np.all(np.isfinite(sample)) or np.any(sample<=0):
                raise ValueError('Invalid height reference sample')
            h=float(rng.choice(sample))
        boxes.append([x,y,0.,x+width,y+width,h])
        patch([x,y,h],[x+width,y,h],[x+width,y+width,h],[x,y+width,h],[0,0,1],0,i)
        patch([x,y,0],[x,y,h],[x,y+width,h],[x,y+width,0],[-1,0,0],1,i)
        patch([x+width,y+width,0],[x+width,y+width,h],[x+width,y,h],[x+width,y,0],[1,0,0],1,i)
        patch([x+width,y,0],[x+width,y,h],[x,y,h],[x,y,0],[0,-1,0],1,i)
        patch([x,y+width,0],[x,y+width,h],[x+width,y+width,h],[x+width,y+width,0],[0,1,0],1,i)
        east=patch([x+width,y,0],[x+pitch,y,0],[x+pitch,y+width,0],[x+width,y+width,0],[0,0,1],2,-1)
        north=patch([x,y+width,0],[x+pitch,y+width,0],[x+pitch,y+pitch,0],[x,y+pitch,0],[0,0,1],2,-1)
        ground_map[ix,iy]=[east,north]
    quad=np.array(corners)
    return City(centers=quad.mean(axis=1),normals=np.array(norm,dtype=float),
      areas=np.array(areas),kind=np.array(kind,dtype=np.int32),bid=np.array(bid,dtype=np.int32),
      corners=quad,boxes=np.array(boxes,dtype=float),ground_map=ground_map,
      pitch=float(pitch),width=float(width),nx=nx,ny=ny)


@njit(cache=True)
def _ray_box(origin,direction,boxes,ignore):
    """Nearest ray/AABB hit, returning (building id, 0 roof, 1 W, 2 E, 3 S, 4 N)."""
    best=1.e16;bestid=-1;bestface=-1
    for i in range(len(boxes)):
        if i==ignore:continue
        # cheap rejection on ground-plan bounding sphere using planar distance
        dx=boxes[i,0]+(boxes[i,3]-boxes[i,0])/2-origin[0]
        dy=boxes[i,1]+(boxes[i,4]-boxes[i,1])/2-origin[1]
        if direction[2]>0 and origin[2]>boxes[i,5]:continue
        tnear=-1.e16;tfar=1.e16;face=-1
        possible=True
        for a in range(3):
            lo=boxes[i,a];hi=boxes[i,a+3];v=direction[a]
            if abs(v)<1e-10:
                if origin[a]<lo or origin[a]>hi: possible=False;break
            else:
                x0=(lo-origin[a])/v;x1=(hi-origin[a])/v
                if x0<x1:
                    near=x0;far=x1;fid=1 if a==0 else (3 if a==1 else 5)
                else:
                    near=x1;far=x0;fid=2 if a==0 else (4 if a==1 else 0)
                if near>tnear:tnear=near;face=fid
                if far<tfar:tfar=far
                if tfar<tnear:possible=False;break
        if possible and tnear>1e-4 and tnear<best:
            best=tnear;bestid=i;bestface=face
    return best,bestid,bestface


@njit(cache=True)
def _trace(origin,direction,boxes,pitch,width,nx,ny,ground_map,ignore):
    best,bid,face=_ray_box(origin,direction,boxes,ignore)
    target=-1
    if bid>=0:
        # 7 surfaces per building, each roof+four walls+two ground patches
        target=7*bid+(0 if face==0 else face)
    if direction[2]<-1e-10:
        t=-origin[2]/direction[2]
        if t>1e-4 and t<best:
            x=origin[0]+t*direction[0];y=origin[1]+t*direction[1]
            if 0<=x<nx*pitch and 0<=y<ny*pitch:
                ix=min(nx-1,int(x/pitch));iy=min(ny-1,int(y/pitch))
                fx=x-ix*pitch;fy=y-iy*pitch
                if fx>=width:target=ground_map[ix,iy,0]
                elif fy>=width:target=ground_map[ix,iy,1]
                # else building ground occupied, prior box hit should have occurred
    return target


@njit(cache=True)
def _lambertian(normal,r1,r2):
    r=np.sqrt(r1);theta=2*np.pi*r2
    a=r*np.cos(theta);b=r*np.sin(theta);c=np.sqrt(max(0.,1-r1))
    if abs(normal[2])<.85: basis=np.array([0.,0.,1.])
    else:basis=np.array([1.,0.,0.])
    u=np.cross(basis,normal);u=u/np.sqrt(np.sum(u*u))
    v=np.cross(normal,u)
    return a*u+b*v+c*normal


@njit(cache=True)
def _sample_quad(quad,r1,r2):
    return quad[0]+r1*(quad[1]-quad[0])+r2*(quad[3]-quad[0])


@njit(cache=True)
def _mc_operator(corners,normals,bid,boxes,ground_map,pitch,width,nx,ny,rays,seed):
    np.random.seed(seed)
    n=len(normals)
    source=np.empty(n*rays,dtype=np.int32)
    target=np.empty(n*rays,dtype=np.int32)
    count=0
    sky=np.zeros(n,dtype=float)
    for i in range(n):
        for j in range(rays):
            o=_sample_quad(corners[i],np.random.random(),np.random.random())+normals[i]*.015
            d=_lambertian(normals[i],np.random.random(),np.random.random())
            dest=_trace(o,d,boxes,pitch,width,nx,ny,ground_map,bid[i])
            if dest<0:
                if d[2]>0:sky[i]+=1.
            else:
                source[count]=i;target[count]=dest;count+=1
    return source[:count],target[:count],sky/rays


def build_reflection_operator(city,rays=24,seed=17):
    """T[target,source]: fraction of Lambertian emitted energy reaching target.
    Finite sample, limited rectangle/flat-roof geometry; rows in each source
    naturally sum <= 1; leftover escapes the finite domain.
    """
    if rays<1:raise ValueError('rays must be positive')
    src,dst,sky=_mc_operator(city.corners,city.normals,city.bid,city.boxes,city.ground_map,
                          city.pitch,city.width,city.nx,city.ny,rays,seed)
    m=len(city.areas)
    t=coo_matrix((np.full(len(src),1/rays),(dst,src)),shape=(m,m)).tocsr()
    # Enforce area-weighted reciprocity: A_i F(i->j) = A_j F(j->i).
    # Sparse symmetric exchange matrix G[target,source] has units of m2.
    # Finite Monte Carlo rays are not inherently reciprocal; this correction
    # prevents reciprocal-exchange violations in the radiosity system.
    g=(t @ diags(city.areas)).tocsr()
    g=((g+g.T)*.5).tocsr()
    # Symmetric balancing preserves reciprocity and ensures 0<=outgoing<=1.
    for _ in range(30):
        outgoing=np.asarray(g.sum(axis=0)).ravel()/city.areas
        if float(outgoing.max())<=1+1e-12:break
        scales=np.minimum(1.,1/np.sqrt(np.maximum(outgoing,1.)))
        g=diags(scales) @ g @ diags(scales)
    # Last-resort uniform attenuation handles extreme area disparities while
    # keeping symmetry exactly intact. Record this as an estimator correction.
    outgoing=np.asarray(g.sum(axis=0)).ravel()/city.areas
    max_out=float(outgoing.max())
    if max_out>1:g=g/max_out
    t=(g @ diags(1/city.areas)).tocsr()
    escape=1-np.asarray(t.sum(axis=0)).reshape(-1)
    if escape.min()<-1e-9:raise RuntimeError('Reflection fractions exceed unity')
    return t,np.maximum(0,escape),sky


@njit(cache=True)
def _shadow_fractions(corners,normals,bid,boxes,ground_map,pitch,width,nx,ny,sun,samples,seed):
    np.random.seed(seed)
    vis=np.zeros(len(normals))
    if sun[2]<=0:return vis
    for i in range(len(normals)):
        if np.dot(normals[i],sun)<=0:continue
        for k in range(samples):
            o=_sample_quad(corners[i],np.random.random(),np.random.random())+normals[i]*.015
            if _trace(o,sun,boxes,pitch,width,nx,ny,ground_map,bid[i])<0:vis[i]+=1
        vis[i]/=samples
    return vis


def shadow_fractions(city,sun,samples=2,seed=31):
    return _shadow_fractions(city.corners,city.normals,city.bid,city.boxes,city.ground_map,
         city.pitch,city.width,city.nx,city.ny,np.array(sun,dtype=float),samples,seed)


def multibounce(city, operator:csr_matrix, source_power, albedo, bounces=4):
    """Power accounting in W; operator columns sum <=1 incl escape.
    Externally applied direct/diffuse source is 'energy entering' the surface
    system, not incoming radiation across the footprint top boundary.
    """
    power=np.asarray(source_power,dtype=float)
    albedo=np.asarray(albedo,dtype=float)
    if np.any(power<0) or np.any((albedo<0)|(albedo>1)):raise ValueError('Invalid power or albedo')
    incoming=power.copy(); absorbed=np.zeros_like(power)
    outgoing_escape=0.;history=[]
    escape=1-np.asarray(operator.sum(axis=0)).ravel()
    for b in range(bounces+1):
        abs_now=incoming*(1-albedo);absorbed+=abs_now
        reflected=incoming*albedo
        if b<bounces:
            lost=float(np.dot(escape,reflected));outgoing_escape+=lost
            incoming=operator @ reflected
            history.append({'bounce':b,'absorbed_W':float(abs_now.sum()),'escaped_W':lost})
        else:
            remaining=float(reflected.sum())
            history.append({'bounce':b,'absorbed_W':float(abs_now.sum()),'unresolved_W':remaining})
    total=float(power.sum());unresolved=float((incoming*albedo).sum())
    residual=total-absorbed.sum()-outgoing_escape-unresolved
    return {'absorbed_W':absorbed,'absorbed_Wm2':absorbed/city.areas,'source_W':total,
          'escaped_W':outgoing_escape,'unresolved_W':unresolved,'residual_W':float(residual),
          'relative_residual':float(abs(residual)/max(total,1)),'history':history}


def dragging_loads(city,wind_u,wind_angle_rad=0.,gust_factor=1.4,cd=1.3):
    bx=city.boxes[:,3]-city.boxes[:,0];by=city.boxes[:,4]-city.boxes[:,1]
    heights=city.boxes[:,5]
    frontage=np.abs(np.cos(wind_angle_rad))*by+np.abs(np.sin(wind_angle_rad))*bx
    area=heights*frontage
    mean=drag_force(DENSITY_AIR,wind_u,cd,area)
    gust=drag_force(DENSITY_AIR,wind_u*gust_factor,cd,area)
    return mean,gust,area


def simulate_thermal_hour(city, temperature, canyon_T, absorb_Wm2, air_T, cloud,
                          wind_ref, relative_humidity, steps=6):
    """Coupled patch thermal capacitance and 0-D canyon air model; hourly step.
    Empirical boundary conditions; no radiative view-factor network in LW.
    """
    kind=city.kind; area=city.areas
    C=np.array([material_capacity(MATERIALS[('roof','wall','ground')[k]])[0] for k in kind])
    conduction=np.array([material_capacity(MATERIALS[('roof','wall','ground')[k]])[1] for k in kind])
    emiss=np.array([MATERIALS[('roof','wall','ground')[k]].emissivity for k in kind])
    length=np.array([MATERIALS[('roof','wall','ground')[k]].rough_length for k in kind])
    vertical=kind==1
    sky_longwave,eps_sky=brunt_cloud_longwave(air_T,relative_humidity,cloud)
    # approximate sky fractions handled separately with modeled sky visibility
    wind=wind_profile(np.maximum(1,city.centers[:,2]),wind_ref)
    scene_volume=(city.nx*city.pitch)*(city.ny*city.pitch)*18.
    canopy_C=DENSITY_AIR*CP_AIR*scene_volume
    ach=4+1.2*wind_ref
    ventilation_coeff=canopy_C*ach/3600
    t=np.asarray(temperature,dtype=float).copy();tc=float(canyon_T)
    floor_ref=air_T-2.
    deep=np.where(kind==2,floor_ref,air_T)
    sky_view=np.clip(getattr(city,'sky_view',np.full(len(kind),.5)),0,1)
    for _ in range(steps):
        wind_near=np.maximum(.2,wind)
        h=convection_coefficient(t,tc,wind_near,length,vertical=vertical)
        # sky + approximate local facade radiance, not full long-wave exchange
        received_LW=sky_view*sky_longwave+(1-sky_view)*STEFAN*tc**4
        netLW=emiss*(received_LW-STEFAN*t**4)
        sensible=h*(t-tc)
        net=absorb_Wm2+netLW-sensible-conduction*(t-deep)
        dt=3600/steps
        # stable explicit integration of thermal skin-depth model
        t=t+np.clip(dt*net/C,-6,6)
        exchange=float(np.dot(area,sensible))
        # Semi-implicit stable canopy ventilation; avoids explicit-Euler
        # oscillation for high-wind air-exchange rates.
        tc=(canopy_C*tc+dt*exchange+dt*ventilation_coeff*air_T)/(canopy_C+dt*ventilation_coeff)
        tc=float(np.clip(tc,air_T-15,air_T+25))
    return t,tc,{'sky_emissivity':eps_sky,'mean_convection_Wm2K':float(np.average(h,weights=area)),
                 'canopy_air_excess_K':float(tc-air_T),'total_sensible_W':exchange}


def hourly_forcing(dt, scenario:Scenario):
    w=irradiance_weather(dt,scenario.cloud_fraction)
    local_hour=dt.hour+dt.minute/60
    # ASSUMED diurnal meteorology, not historical observations or forecasts.
    air_C=22+5*np.sin(2*np.pi*(local_hour-9)/24)
    humidity=np.clip(.67-.16*np.sin(2*np.pi*(local_hour-7)/24),.3,.9)
    wind_mean=scenario.wind_ref_ms*(1+.15*np.sin(2*np.pi*local_hour/24))
    wind_angle=float(2*np.pi*(.15+.12*np.sin(2*np.pi*local_hour/24)))
    return {**w,'air_T_K':float(air_C+273.15),'RH':float(humidity),'wind_ref_ms':float(wind_mean),'wind_angle':wind_angle}


def run_daily(city,operator,escape,skyview,scenario:Scenario,date_str='2026-07-15',bounces=4,shadow_samples=2, collect_faces=False):
    setattr(city,'sky_view',skyview)
    dt0=datetime.fromisoformat(date_str+'T00:00:00').replace(tzinfo=ZoneInfo('America/New_York'))
    kind=city.kind
    albedo=np.array([scenario.roof_albedo if x==0 else (.30 if x==1 else .12) for x in kind])
    t=np.full(len(kind),295.15);tc=295.15
    rows=[];snapshot=None; perkind=[];face_rows=[]
    cumulative_shortwave=np.zeros(3)
    for hour in range(24):
        now=dt0+timedelta(hours=hour)
        w=hourly_forcing(now,scenario)
        sun=w['sun'];normdot=np.maximum(0,city.normals @ sun)
        vis=shadow_fractions(city,sun,samples=shadow_samples,seed=123+hour)
        direct=w['dni']*normdot*vis*city.areas
        diffuse=w['dhi']*skyview*city.areas
        initial=direct+diffuse
        radiation=multibounce(city,operator,initial,albedo,bounces)
        if radiation['relative_residual']>1e-9:raise AssertionError('Energy accounting error')
        t,tc,therm=simulate_thermal_hour(city,t,tc,radiation['absorbed_Wm2'],
                       w['air_T_K'],scenario.cloud_fraction,w['wind_ref_ms'],w['RH'])
        # Per-building wind evaluated at mid-height, not a uniform 100 m wind.
        building_wind=wind_profile(.5*city.boxes[:,5],w['wind_ref_ms'])
        mean_drag,gust_drag,frontal=dragging_loads(city,building_wind,w['wind_angle'])
        means={('roof','wall','ground')[k]:float(np.average(t[kind==k]-273.15,weights=city.areas[kind==k])) for k in range(3)}
        absorbed={('roof','wall','ground')[k]:float(radiation['absorbed_W'][kind==k].sum()) for k in range(3)}
        for k,key in enumerate(['roof','wall','ground']):cumulative_shortwave[k]+=absorbed[key]*3600
        row={'scenario':scenario.name,'hour':hour,'time_local':now.isoformat(),
             'cloud_fraction_assumed':scenario.cloud_fraction,'ghi_Wm2':w['ghi'],'dni_Wm2':w['dni'],
             'dhi_Wm2':w['dhi'],'solar_elevation_deg':w['elevation_deg'],
             'air_C':w['air_T_K']-273.15,'wind_ref_ms':w['wind_ref_ms'],
             'wind_direction_deg':np.rad2deg(w['wind_angle']),
             'canopy_air_C':tc-273.15,'canopy_air_excess_K':tc-w['air_T_K'],
             **{f'{k}_mean_surface_C':v for k,v in means.items()},
             **{f'{k}_absorbed_W':v for k,v in absorbed.items()},
             'source_W':radiation['source_W'],'escaped_W':radiation['escaped_W'],
             'unresolved_W':radiation['unresolved_W'],'energy_relative_residual':radiation['relative_residual'],
             'max_face_absorbed_Wm2':float(radiation['absorbed_Wm2'].max()),
             'mean_building_drag_N':float(np.mean(mean_drag)),
             'max_gust_building_drag_N':float(np.max(gust_drag)),**therm}
        rows.append(row)
        if collect_faces and w['ghi']>5:
            face_rows.append({
                'scenario':scenario.name,'hour':hour,'face_idx':np.arange(len(kind),dtype=np.int32),
                'block_id':np.arange(len(kind),dtype=np.int32)//7,
                'kind':kind.copy(), 'height_m':city.centers[:,2].copy(),
                'x':city.centers[:,0].copy(),'y':city.centers[:,1].copy(),
                'nx':city.normals[:,0].copy(),'ny':city.normals[:,1].copy(),
                'nz':city.normals[:,2].copy(),'area':city.areas.copy(),
                'albedo':albedo.copy(), 'skyview':skyview.copy(),
                'ghi':np.full(len(kind),w['ghi']), 'dni':np.full(len(kind),w['dni']),
                'dhi':np.full(len(kind),w['dhi']),
                'sun_east':np.full(len(kind),sun[0]),'sun_north':np.full(len(kind),sun[1]),
                'sun_up':np.full(len(kind),sun[2]),
                'direct_Wm2':direct/city.areas,'diffuse_Wm2':diffuse/city.areas,
                'no_reflection_Wm2':(1-albedo)*initial/city.areas,
                'multibounce_Wm2':radiation['absorbed_Wm2'].copy(),
                'modeled_surface_C':(t-273.15).copy()
            })
        if hour==12:snapshot={'temperature_C':t-273.15,'absorbed_Wm2':radiation['absorbed_Wm2'],
                              'no_reflection_Wm2':(1-albedo)*initial/city.areas,
                              'initial_Wm2':initial/city.areas, 'skyview':skyview,
                              'sun':sun,'direct_Wm2':direct/city.areas,'diffuse_Wm2':diffuse/city.areas}
        perkind.append(absorbed)
    return rows,snapshot,cumulative_shortwave,face_rows


def load_anchored_height_samples(path):
    """Read observed NYC roof heights (meters) to anchor only the synthetic height histogram."""
    import json
    data=json.loads(Path(path).read_text())
    if data.get('type')!='FeatureCollection':raise ValueError('Expected GeoJSON FeatureCollection')
    heights=[]
    for feat in data['features']:
        prop=feat.get('properties',{})
        meters=float(prop['height_m'])
        if prop.get('height_roof_ft') is not None and not np.isclose(meters,float(prop['height_roof_ft'])*.3048,atol=1e-6):
            raise ValueError('Conflicting height units in NYC source snapshot')
        if np.isfinite(meters) and 2<meters<500:heights.append(meters)
    if len(heights)<10:raise ValueError('Too few verified heights in reference snapshot')
    return np.asarray(heights,dtype=float)

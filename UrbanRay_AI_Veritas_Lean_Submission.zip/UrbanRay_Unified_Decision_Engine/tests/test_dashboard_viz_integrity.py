"""Regression tests for UrbanRay's archived standalone dashboard data.

These tests check numerical consistency, not physical accuracy of the simulator.
"""
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
HTML = PROJECT / 'outputs/ai_upgrade/UrbanRay_AI_Explorer_OFFLINE.html'


def load_data():
    s=HTML.read_text(encoding='utf-8')
    pos=s.index('const D=')+len('const D=')
    return json.JSONDecoder().raw_decode(s[pos:])[0]


def test_all_three_methods_present_and_distinct():
    d=load_data()
    assert len(d['times'])==24 and len(d['rankings'])==88
    assert len(d['mesh']['i'])==2082
    for scenario in ('dark_roof','reflective_roof'):
        for t in d['times']:
            states=d['states'][scenario][t]
            assert set(states)=={'ai','physics','no_reflection'}
            assert all(len(states[m])==2082 for m in states)
            assert all(p>=n-1e-7 for p,n in zip(states['physics'],states['no_reflection']))
    values=d['states']['dark_roof'][d['times'][17]]
    assert values['ai']!=values['physics']
    assert values['no_reflection']!=values['physics']


def test_roof_series_rankings_match_stored_summaries():
    d=load_data()
    for row in d['rankings']:
        b=d['building_series'][row['building_id']]
        daylight=[i for i,x in enumerate(b['dark_roof']['physics']) if x>.001]
        assert daylight
        for method,key in [('ai','ai_estimated_roof_solar_reduction_Wm2'),('physics','physics_roof_solar_reduction_Wm2')]:
            estimate=sum(b['dark_roof'][method][i]-b['reflective_roof'][method][i] for i in daylight)/len(daylight)
            assert abs(estimate-row[key])<.005


def test_absolute_map_fixed_scale_covers_archive():
    d=load_data()
    extreme=max(v for scenario in d['states'].values() for t in scenario.values() for m in t.values() for v in m)
    assert extreme<=800, f'Fixed absolute color scale may clip: archive max is {extreme}'


def test_roof_geometry_face_indices_are_valid():
    d=load_data();g=d['mesh'];vertices=len(g['x']);faces=len(g['i'])
    assert vertices==len(g['y'])==len(g['z'])
    assert all(0<=index<vertices for name in ('i','j','k') for index in g[name])
    assert len(g['roof_i'])==306 and all(0<=i<faces for i in g['roof_i'])

import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from decision_validation_gate import audit_roofs,audit_wall,audit_satellite,generate


def roofs():
    return pd.DataFrame({'building_id':['a','b','c'],
        'physics_solar_heat_avoided_kWh_day':[9.,7.,5.],
        'ai_solar_heat_avoided_kWh_day':[8.,10.,4.],
        'no_reflection_solar_heat_avoided_kWh_day':[9.,6.,8.],
        'direct_ai_solar_heat_avoided_kWh_day':[8.,10.,4.],
        'observed_simulated_hours':[24]*3,
        'heldout_roof_portion_m2':[10.]*3})


def test_roof_paired_selection_and_gain():
    r={x['method']:x for x in audit_roofs(roofs(),ks=(1,))}
    assert r['ai']['selected_building_ids']==['b']
    assert r['no_reflection']['selected_building_ids']==['a']
    assert r['ai']['selection_changed_vs_no_reflection']
    assert r['ai']['gain_vs_no_reflection_kWh_solar_heat']==pytest.approx(-2.)
    assert not r['ai']['outperforms_no_reflection_on_simulated_decision']
    assert not r['ai']['observed_intervention_benefit']


def test_roof_tie_is_deterministic():
    df=roofs();df.loc[0,'ai_solar_heat_avoided_kWh_day']=10.
    assert next(x for x in audit_roofs(df,ks=(1,)) if x['method']=='ai')['selected_building_ids']==['a']


def test_roof_rejects_duplicate_building():
    df=roofs();df.loc[1,'building_id']='a'
    with pytest.raises(ValueError,match='unique'):audit_roofs(df,ks=(1,))


def test_roof_rejects_missing_values():
    df=roofs();df.loc[0,'ai_solar_heat_avoided_kWh_day']=np.nan
    with pytest.raises(ValueError,match='invalid'):audit_roofs(df,ks=(1,))


def test_roof_rejects_partial_hours():
    df=roofs();df.loc[0,'observed_simulated_hours']=23
    with pytest.raises(ValueError,match='Incomplete'):audit_roofs(df,ks=(1,))


def test_wall_selection_changed_and_capture():
    df=pd.DataFrame([dict(method=n,top_k_wall_patches=1,num_spatially_heldout_wall_patches=2,
        percent_of_reference_topk_exposure=v,selected_face_ids=f) for n,v,f in [('ai_residual',80.,'12'),('direct_exposure_rule',20.,'13')]])
    row=audit_wall(df)[0]
    assert row['specialist_gain_percentage_points_simulated']==60.
    assert row['selection_changed']
    assert row['independently_observed_wall_reflection'] is False


def test_satellite_equal_scene_not_pixel_weighted():
    data={'dates':{'2025-01-01':{'cells':100,'decision_ai':1,'physics':2,'no_reflection':3},
                   '2025-01-02':{'cells':1,'decision_ai':9,'physics':8,'no_reflection':7}}}
    x=audit_satellite(data)
    assert x['means_C']['ai_mae_C']==5.
    assert x['n_development_scenes']==2 and x['correlated_grid_cell_rows']==101
    assert x['observed_decision_success_established'] is False


def test_packaged_evidence_gate_is_conservative():
    r=generate()
    assert not r['evidence_gate']['real_world_decision_improvement_shown']
    assert len(r['roof_selection_simulation'])==9
    assert r['satellite_temperature_proxy_development']['n_development_scenes']==5
    for x in r['roof_selection_simulation']:
        if x['method']=='ai':assert not x['outperforms_no_reflection_on_simulated_decision']


def test_invalid_k_fails():
    with pytest.raises(ValueError,match='Invalid k'):audit_roofs(roofs(),ks=(4,))

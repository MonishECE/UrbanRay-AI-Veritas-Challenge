"""Research-integrity tests for UrbanRay's new practical/observational checks."""
import json, sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from decision_benchmark import build_decision_audit
from reflection_hotspot_audit import score_hotspots
from observational_evidence import archived_landsat_evidence
from validate_ai_landsat import check_comparison_audit,paired_scene_metrics
from validate_landsat_pixels import load_faces


def holdout_roof_small():
    rows=[]
    for bid,face,gain in [('b1',0,40.),('b2',1,25.),('b3',2,10.)]:
        for h in range(24):
            for scenario in ('dark_roof','reflective_roof'):
                v=gain if scenario=='dark_roof' else 0.
                rows.append({'building_id':bid,'face_id':face,'kind':'roof','time_utc':f'2026-06-05T{h:02d}:00Z',
                    'scenario':scenario,'physics_label_Wm2':v,
                    'pred_No-reflection_physics':v if face!=2 else 0,
                    'pred_Reflection-residual_AI':v,
                    'pred_Direct_AI':v})
    return pd.DataFrame(rows)


def test_decision_integrates_heat_over_24h_not_electricity():
    buildings,score,meta=build_decision_audit(holdout_roof_small(),np.array([10.,20.,30.]),k_values=(1,2))
    saved=buildings.set_index('building_id')
    assert saved.loc['b1','physics_solar_heat_avoided_kWh_day']==pytest.approx(40*10*24/1000)
    assert saved.loc['b2','physics_solar_heat_avoided_kWh_day']==pytest.approx(25*20*24/1000)
    assert 'NOT kWh electricity' in meta['impact_metric']
    assert (score[score.method=='ai'].simulator_regret_kWh_day==0).all()


def test_decision_rejects_missing_scenario_and_duplicate():
    df=holdout_roof_small()
    with pytest.raises(ValueError,match='Unpaired'):
        build_decision_audit(df.iloc[:-1],np.ones(3))
    with pytest.raises(ValueError,match='Duplicate'):
        build_decision_audit(pd.concat([df,df.iloc[[0]]]),np.ones(3))


def test_hotspot_benchmark_requires_full_day():
    df=pd.DataFrame({'kind':['wall']*24,'scenario':['dark_roof']*24,
        'face_id':[3]*24,'time_utc':[str(x) for x in range(24)],
        'physics_label_Wm2':[12]*24,'pred_No-reflection_physics':[3]*24,
        'pred_Reflection-residual_AI':[11]*24})
    face,_,meta=score_hotspots(df,k_values=(1,))
    assert face.loc[0,'truth_Wh_per_m2_day']==216
    assert meta['field_hotspot_detection_accuracy_proven'] is False
    with pytest.raises(ValueError,match='24 hourly'):
        score_hotspots(df.iloc[:-1],k_values=(1,))


def test_real_landsat_audit_available_but_physics_only():
    evidence=archived_landsat_evidence()
    assert evidence['heldout']['scenes']==5
    assert evidence['heldout']['raw_scene_proxy_MAE_C']==3.526
    assert evidence['AI_measured_temperature_validation_completed'] is False


def verified_meta():
    return {'radiation_method':'compare','compared_methods':['physics','ai','no_reflection'],
       'weather_provenance_verified':True,'weather_source':'Open-Meteo archive file with matching provenance',
       'warmup_hours':48,'evaluated_hours':24,'context_included':False,
       'weather_file':'nyc_gridded_weather.csv'}


def test_observational_comparator_rejects_unverified_or_synthetic():
    good=verified_meta();check_comparison_audit(good)
    for patch in [{'weather_provenance_verified':False},{'warmup_hours':0},
                  {'weather_file':'SMOKE_ONLY.csv'},{'radiation_method':'ai'}]:
        with pytest.raises(ValueError):
            check_comparison_audit({**good,**patch})


def test_paired_observational_scores_use_exact_same_scenes():
    def frames(method):
        return pd.DataFrame([
            {'scene_id':'A','acquisition_utc':'2026-06-05T15:40Z','observed_scene_mean_C':30.,'modeled_scene_mean_proxy_C': {'ai':32.,'physics':31.,'no_reflection':33.}[method]},
            {'scene_id':'B','acquisition_utc':'2026-06-13T15:40Z','observed_scene_mean_C':35.,'modeled_scene_mean_proxy_C': {'ai':34.,'physics':35.,'no_reflection':31.}[method]},
        ])
    scenes={k:frames(k) for k in ('ai','physics','no_reflection')}
    joined,r=paired_scene_metrics(scenes)
    assert len(joined)==2
    assert r['scene_mean_results']['physics']['scene_mean_proxy_MAE_C']==.5
    assert r['scene_mean_results']['ai']['scene_mean_proxy_MAE_C']==1.5
    assert not r['ai_observational_roof_accuracy_established']
    scenes['ai'].loc[0,'observed_scene_mean_C']=40.
    with pytest.raises(ValueError,match='Observed satellite'):
        paired_scene_metrics(scenes)


def test_comparison_faces_require_radiation_method_selection(tmp_path):
    data=[]
    for method in ('physics','ai','no_reflection'):
        data.append({'time_utc':'2026-06-05T15:00Z','face_id':0,'scenario':'dark_roof',
                     'radiation_method':method,'area_m2':1.,'x_m':0.,'y_m':0.,
                     'surface_temp_C_simulated':20.,'kind':'roof','air_temp_C_grid':21.})
    path=tmp_path/'faces.csv';pd.DataFrame(data).to_csv(path,index=False)
    with pytest.raises(ValueError,match='specify method'):
        load_faces(faces_csv=path)
    filtered,_=load_faces(faces_csv=path,method='ai')
    assert len(filtered)==1 and filtered.iloc[0].radiation_method=='ai'


def test_dashboard_contains_new_evidence_fields():
    html=(ROOT/'outputs/ai_upgrade/UrbanRay_AI_Explorer_OFFLINE.html').read_text(encoding='utf-8')
    assert 'AI-estimated reflected solar heat' in html
    assert 'Independent satellite evidence' in html
    d=json.JSONDecoder().raw_decode(html[html.index('const D=')+len('const D='):])[0]
    assert len(d['rankings'])==88
    for row in d['rankings']:
        assert np.isfinite(row['ai_solar_heat_avoided_kWh_simulated_day'])
    assert 'no_Ai_observational_validation_done' in html

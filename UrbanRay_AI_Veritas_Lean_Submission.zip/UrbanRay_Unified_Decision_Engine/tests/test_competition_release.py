"""Evidence, source-integrity and model-comparison regression tests."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from validate_unified_landsat import summarize_paired_pixels
from competition_evidence_audit import audit


def frames():
    d={}
    for name,v in [('physics',29.),('decision_ai',30.),('no_reflection',31.)]:
        d[name]=pd.DataFrame([{
            'scene_id':'development','acquisition_utc':'2025-06-23T15:30:00Z',
            'center_lon':-73.0,'center_lat':40.0,
            'observed_landsat_lst_C':30.,'modeled_emission_proxy_C':v,
            'landsat_uncertainty_K':2.5,
        }])
    return d


def test_paired_cells_consistent_provenance():
    paired,scenes,report=summarize_paired_pixels(frames())
    assert len(paired)==1 and len(scenes)==1
    assert report['paired_scenes']==1
    assert report['pairwise_coverage']['physics']['paired_grid_cells']==1
    assert report['roof_accuracy_established'] is False


def test_paired_cells_reject_uncertainty_mismatch():
    x=frames();x['decision_ai'].loc[0,'landsat_uncertainty_K']=5.0
    with pytest.raises(ValueError,match='uncertainty'):
        summarize_paired_pixels(x)


def test_paired_cells_reject_nonfinite_predictions_and_uncertainty():
    for column, value in [('modeled_emission_proxy_C',float('nan')),('landsat_uncertainty_K',-1.),('center_lat',np.inf)]:
        x=frames();x['decision_ai'].loc[0,column]=value
        with pytest.raises(ValueError):
            summarize_paired_pixels(x)


def test_paired_cells_track_unpaired_method_coverage():
    x=frames()
    x['physics']=pd.concat([x['physics'],x['physics'].assign(center_lat=41.)],ignore_index=True)
    p,s,a=summarize_paired_pixels(x)
    assert len(p)==1 and len(s)==1
    assert a['pairwise_coverage']['physics']['unpaired_grid_cells_excluded']==1


def test_reviewer_evidence_report_consistent_with_source_assets():
    report=audit()
    assert report['dashboard_state']['full_buildings']==88
    assert report['model_weights_sha256_match_embedded_decision_report'] is True
    assert report['reported_2025_development_satellite']['correlated_matched_grid_cells']==135
    assert report['reported_2025_development_satellite']['ai_better_than_physics_dates']==0
    assert report['reported_2025_development_satellite']['ai_better_than_no_reflection_dates']==3
    assert all(not x['ai_improves'] for x in report['simulator_roof_selection'].values())

# UrbanRay decision evidence gate — reproducible audit

**Status: observational decision advantage NOT established.** This report recomputes decisions from packaged evidence, not original physical experiments.

## Rooftop selection (simulator-relative, held-out roof portions)

| K | AI and no-reflection choose same set? | AI gain over no-reflection (modeled solar heat kWh/day) |
|---:|:---:|---:|
| 3 | Yes | 0.0000 |
| 5 | Yes | 0.0000 |
| 10 | Yes | 0.0000 |

These are **roof portions** and an all-roofs-change scenario; no individual building intervention impact is established.

## Reflection-hotspot selection (simulator-relative wall patches)

| K | Specialist captured | Direct-exposure rule captured | Difference (percentage points) |
|---:|---:|---:|---:|
| 10 | 68.94% | 3.27% | 65.67 |
| 20 | 81.14% | 11.46% | 69.69 |
| 50 | 83.52% | 23.36% | 60.16 |

This is a comparison against simulator labels, not independent wall-sensor observations.

## Satellite temperature-proxy development scenes

There are **5** already-inspected scenes (135 correlated grid cells). Scene-equal mean grid-cell MAEs: AI **6.227°C**, physics **6.169°C**, no-reflection **6.323°C**.
AI is lower-error on **3/5** scenes versus no-reflection and **0/5** versus physics.

## Evidence gate

- Simulator wall-hotspot advantage: **yes**.
- Simulator roof selection advantage at reported K: **no**.
- Real-world screening improvement: **NOT SHOWN**.
- Why: No independently observed post-intervention outcomes or wall reflection ground truth; satellite scenes provide aggregate temperature proxy errors, not observed screening decisions.

## How to reproduce

Run `python decision_validation_gate.py` from the package root. The script reads three included evidence files, checks required fields and integrity, and rewrites `outputs/decision_validation_gate/report.json` and `report.md`. It does not execute models, download data, or reinterpret simulator labels as observations.

## What would actually close the gap

1. Before collecting new evidence, register a fixed decision target and evaluation unit, independent baseline, and the K values.
2. Freeze model weights and screening rules. Reserve **new** dates and geographical blocks not previously used for model selection.
3. Obtain independent observed **wall shortwave irradiance/reflection** for hotspot screening; for cool-roof decisions, obtain comparable measured before/after roof and ambient observations with appropriate controls.
4. Evaluate *paired decisions at the same budget* against observed outcomes, with scene/building-level clustering and uncertainty; do not use correlated hourly patches as independent samples.
5. Keep single-roof causal effects separate from all-roofs simulations, and disclose any failure to beat baselines.

The included Landsat proxy scenes cannot retroactively establish actual cooling or observed screening success.
